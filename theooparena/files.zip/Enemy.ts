import { Character, ActionResult } from "./Character";
import { Hero } from "./Hero";

/**
 * Enemy — Abstract class extending Character
 * Demonstrates: Inheritance, abstract specialAbility, wave scaling
 */
export abstract class Enemy extends Character {
  protected _enemyType: string;
  protected _xpReward: number;

  constructor(
    name: string, enemyType: string, maxHp: number, damage: number,
    defense: number, speed: number, xpReward: number
  ) {
    super(name, maxHp, damage, defense, speed, 0);
    this._enemyType = enemyType;
    this._xpReward = xpReward;
  }

  get enemyType(): string { return this._enemyType; }
  get xpReward(): number { return this._xpReward; }

  scaleForWave(wave: number): void {
    const mult = 1 + (wave - 1) * 0.3;
    this._maxHp   = Math.floor(this._maxHp * mult);
    this._currentHp = this._maxHp;
    this._damage  = Math.floor(this._damage * mult);
  }

  // Virtual — default AI just basic attacks
  decideAction(target: Hero): ActionResult {
    const dmg = Math.max(1, this.calculateBaseDamage() - target.defense);
    target.takeDamage(dmg);
    return {
      actionKey: "enemy_basic_attack",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 0,
      logEntry: `${this._name} attacks ${target.name} for ${dmg}!`,
      statusApplied: "", critical: false, success: true,
    };
  }

  abstract specialAbility(target: Hero): ActionResult;

  override toSnapshot(): Record<string, unknown> {
    return { ...super.toSnapshot(), enemyType: this._enemyType, xpReward: this._xpReward };
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export class Goblin extends Enemy {
  constructor() { super("Goblin", "Goblin", 40, 8, 2, 10, 25); }

  override specialAbility(target: Hero): ActionResult {
    let total = 0;
    for (let i = 0; i < 3; i++) {
      const dmg = Math.max(1, Math.floor(this.calculateBaseDamage() * 0.6) - target.defense);
      target.takeDamage(dmg);
      total += dmg;
    }
    return {
      actionKey: "goblin_frenzy",
      actorName: this._name, targetName: target.name,
      damageDealt: total, healAmount: 0, manaCost: 0,
      logEntry: `${this._name} frenzies — 3 rapid hits for ${total} total!`,
      statusApplied: "", critical: false, success: true,
    };
  }

  override decideAction(target: Hero): ActionResult {
    return Math.random() < 0.3 ? this.specialAbility(target) : super.decideAction(target);
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Troll — overrides decideAction to regen first, then calls super()
 * Demonstrates: Conditional super() delegation
 */
export class Troll extends Enemy {
  constructor() { super("Troll", "Troll", 120, 14, 6, 4, 60); }

  // Override: heal when low HP, then delegate to parent AI
  override decideAction(target: Hero): ActionResult {
    if (this.hpPct < 0.5) {
      const healed = this.heal(20);
      return {
        actionKey: "troll_regen",
        actorName: this._name, targetName: this._name,
        damageDealt: 0, healAmount: healed, manaCost: 0,
        logEntry: `${this._name} regenerates ${healed} HP!`,
        statusApplied: "", critical: false, success: true,
      };
    }
    return super.decideAction(target); // delegates to Enemy.decideAction
  }

  override specialAbility(target: Hero): ActionResult {
    const dmg = Math.max(1, Math.floor(this.calculateBaseDamage() * 1.6) - target.defense);
    target.takeDamage(dmg);
    return {
      actionKey: "ground_slam",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 0,
      logEntry: `${this._name} SLAMS the ground for ${dmg}!`,
      statusApplied: "", critical: false, success: true,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export class Dragon extends Enemy {
  private _breathCharges: number = 3;

  constructor() { super("Dragon", "Dragon", 200, 22, 10, 7, 120); }

  override specialAbility(target: Hero): ActionResult {
    if (this._breathCharges <= 0) return super.decideAction(target);
    this._breathCharges--;
    const dmg = Math.max(1, Math.floor(this.calculateBaseDamage() * 1.8) - target.defense);
    target.takeDamage(dmg);
    target.applyStatus("Burning", 3, 6);
    return {
      actionKey: "fire_breath",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 0,
      logEntry: `${this._name} breathes FIRE for ${dmg}! (${this._breathCharges} charges left)`,
      statusApplied: "Burning", critical: false, success: true,
    };
  }

  override decideAction(target: Hero): ActionResult {
    return this._breathCharges > 0 && Math.random() < 0.5
      ? this.specialAbility(target)
      : super.decideAction(target);
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export class Lich extends Enemy {
  constructor() { super("Lich", "Lich", 160, 18, 5, 9, 150); }

  override specialAbility(target: Hero): ActionResult {
    const dmg = Math.max(1, Math.floor(this.calculateBaseDamage() * 1.2) - target.defense);
    target.takeDamage(dmg);
    const healed = this.heal(Math.floor(dmg * 0.5));
    return {
      actionKey: "soul_drain",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: healed, manaCost: 0,
      logEntry: `${this._name} drains ${dmg} from ${target.name} and heals ${healed}!`,
      statusApplied: "", critical: false, success: true,
    };
  }

  override decideAction(target: Hero): ActionResult {
    return Math.random() < 0.4 ? this.specialAbility(target) : super.decideAction(target);
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export type EnemyType = "Goblin" | "Troll" | "Dragon" | "Lich";

export function createEnemy(type: EnemyType, wave: number = 1): Enemy {
  const enemy = (() => {
    switch (type) {
      case "Goblin": return new Goblin();
      case "Troll":  return new Troll();
      case "Dragon": return new Dragon();
      case "Lich":   return new Lich();
    }
  })();
  if (wave > 1) enemy.scaleForWave(wave);
  return enemy;
}

export const WAVE_COMPOSITIONS: Record<number, EnemyType[]> = {
  1: ["Goblin", "Goblin"],
  2: ["Goblin", "Troll"],
  3: ["Troll", "Dragon"],
  4: ["Dragon", "Lich"],
  5: ["Lich", "Dragon"],
};
