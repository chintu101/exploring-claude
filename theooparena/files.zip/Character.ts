import { Entity } from "./Entity";

export interface StatusEffect {
  name: string;
  duration: number;
  value: number;
}

export interface ActionResult {
  actionKey: string;
  actorName: string;
  targetName: string;
  damageDealt: number;
  healAmount: number;
  manaCost: number;
  logEntry: string;
  statusApplied: string;
  critical: boolean;
  success: boolean;
}

/**
 * Character — Abstract class extending Entity
 * Demonstrates: Inheritance, Encapsulation, super()
 */
export abstract class Character extends Entity {
  protected _damage: number;
  protected _defense: number;
  protected _speed: number;
  protected _mana: number;
  protected _maxMana: number;
  protected _statusEffects: StatusEffect[] = [];

  constructor(
    name: string, maxHp: number, damage: number,
    defense: number, speed: number, maxMana: number
  ) {
    super(name, maxHp); // super() — calls Entity constructor
    this._damage = damage;
    this._defense = defense;
    this._speed = speed;
    this._mana = maxMana;
    this._maxMana = maxMana;
  }

  get defense(): number { return this._defense; }
  get speed(): number { return this._speed; }
  get mana(): number { return this._mana; }
  get maxMana(): number { return this._maxMana; }
  get statusEffects(): StatusEffect[] { return [...this._statusEffects]; }

  applyStatus(name: string, duration: number, value: number): void {
    this._statusEffects.push({ name, duration, value });
  }

  hasStatus(name: string): boolean {
    return this._statusEffects.some(s => s.name === name);
  }

  tickStatusEffects(): string[] {
    const logs: string[] = [];
    for (const effect of this._statusEffects) {
      if (effect.name === "Burning" || effect.name === "Bleeding") {
        const dmg = this.takeDamage(effect.value);
        logs.push(`${this._name} takes ${dmg} from ${effect.name}!`);
      }
      effect.duration--;
    }
    this._statusEffects = this._statusEffects.filter(s => s.duration > 0);
    return logs;
  }

  spendMana(amount: number): boolean {
    if (this._mana < amount) return false;
    this._mana -= amount;
    return true;
  }

  restoreMana(amount: number): void {
    this._mana = Math.min(this._maxMana, this._mana + amount);
  }

  // Virtual — subclasses override to change damage formula
  calculateBaseDamage(): number {
    return this._damage;
  }

  toSnapshot(): Record<string, unknown> {
    return {
      name: this._name,
      maxHp: this._maxHp,
      currentHp: this._currentHp,
      damage: this._damage,
      defense: this._defense,
      speed: this._speed,
      mana: this._mana,
      maxMana: this._maxMana,
      statusEffects: this._statusEffects,
      isAlive: this.isAlive,
    };
  }
}
