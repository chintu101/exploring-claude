/**
 * Entity — Abstract base class (root of the hierarchy)
 * Demonstrates: Abstraction, Encapsulation
 */
export abstract class Entity {
  protected _name: string;
  protected _maxHp: number;
  protected _currentHp: number;

  constructor(name: string, maxHp: number) {
    this._name = name;
    this._maxHp = maxHp;
    this._currentHp = maxHp;
  }

  get name(): string { return this._name; }
  get maxHp(): number { return this._maxHp; }
  get currentHp(): number { return this._currentHp; }
  get isAlive(): boolean { return this._currentHp > 0; }
  get hpPct(): number { return this._currentHp / this._maxHp; }

  takeDamage(amount: number): number {
    const dmg = Math.max(0, Math.floor(amount));
    this._currentHp = Math.max(0, this._currentHp - dmg);
    return dmg;
  }

  heal(amount: number): number {
    const hp = Math.max(0, Math.floor(amount));
    const actual = Math.min(hp, this._maxHp - this._currentHp);
    this._currentHp += actual;
    return actual;
  }

  // Abstract — every subclass must serialise itself
  abstract toSnapshot(): Record<string, unknown>;
}
