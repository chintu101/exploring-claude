export interface TraceStep {
  className: string;
  methodName: string;
  codeLine: string;
  description: string;
  inheritanceChain: string[];
  concept: string;
}

export interface CodeTrace {
  actionKey: string;
  title: string;
  summary: string;
  steps: TraceStep[];
}

const TRACES: Record<string, CodeTrace> = {
  basic_attack: {
    actionKey: "basic_attack",
    title: "Hero.basicAttack()",
    summary: "The Hero base class runs the attack. calculateBaseDamage() is polymorphic — each hero subclass overrides it.",
    steps: [
      { className: "Hero", methodName: "basicAttack()", codeLine: "const dmg = Math.max(1, this.calculateBaseDamage() - target.defense)",
        description: "Hero.basicAttack() calls calculateBaseDamage() — this resolves to the SUBCLASS override due to polymorphism.",
        inheritanceChain: ["Hero", "Character", "Entity"], concept: "Polymorphism" },
      { className: "Character", methodName: "calculateBaseDamage()", codeLine: "return this._damage",
        description: "The base implementation simply returns the _damage stat.",
        inheritanceChain: ["Character", "Entity"], concept: "Encapsulation" },
      { className: "Entity", methodName: "takeDamage()", codeLine: "this._currentHp = Math.max(0, this._currentHp - dmg)",
        description: "Entity.takeDamage() clamps health to 0 minimum. _currentHp is private — only this method can modify it.",
        inheritanceChain: ["Entity"], concept: "Encapsulation" },
    ],
  },
  magic_bolt: {
    actionKey: "magic_bolt",
    title: "Mage.basicAttack() [OVERRIDE]",
    summary: "Mage completely replaces basicAttack() — magic bypasses armor. Full method override.",
    steps: [
      { className: "Mage", methodName: "basicAttack()", codeLine: "const dmg = Math.max(1, this.calculateBaseDamage()) // no defense subtraction!",
        description: "Mage overrides basicAttack() entirely. No target.defense subtraction — magic bypasses armor.",
        inheritanceChain: ["Mage", "Hero", "Character", "Entity"], concept: "Method Override" },
      { className: "Mage", methodName: "calculateBaseDamage()", codeLine: "const spellPower = this._damage + (this._mana / this._maxMana) * 10",
        description: "Mage also overrides calculateBaseDamage(). Spell power scales with current mana percentage.",
        inheritanceChain: ["Mage", "Hero", "Character", "Entity"], concept: "Polymorphism" },
    ],
  },
  whirlwind_strike: {
    actionKey: "whirlwind_strike",
    title: "Warrior.specialAbility()",
    summary: "Warrior uses super() to get the base damage, then adds a rage bonus based on missing HP.",
    steps: [
      { className: "Warrior", methodName: "specialAbility()", codeLine: "const dmg = Math.floor(this.calculateBaseDamage() * 1.5) - target.defense",
        description: "Calls calculateBaseDamage() which chains to super() for the rage bonus.",
        inheritanceChain: ["Warrior", "Hero", "Character", "Entity"], concept: "Polymorphism" },
      { className: "Warrior", methodName: "calculateBaseDamage()", codeLine: "const base = super.calculateBaseDamage(); const rage = Math.floor(ragePct * 15)",
        description: "super.calculateBaseDamage() gets the base damage from Character, then Warrior adds rage based on missing HP.",
        inheritanceChain: ["Warrior", "Character"], concept: "super()" },
      { className: "Hero", methodName: "spendMana()", codeLine: "if (this._mana < amount) return false; this._mana -= amount",
        description: "Mana is encapsulated — spendMana() validates and deducts atomically. Returns false if insufficient.",
        inheritanceChain: ["Hero", "Character"], concept: "Encapsulation" },
    ],
  },
  fireball: {
    actionKey: "fireball",
    title: "Mage.specialAbility() — Fireball",
    summary: "Mana-scaled damage + chance to apply Burning status effect.",
    steps: [
      { className: "Mage", methodName: "specialAbility()", codeLine: "const dmg = Math.floor(this.calculateBaseDamage() * 2)",
        description: "Fireball does 200% spell power. calculateBaseDamage() returns mana-scaled value.",
        inheritanceChain: ["Mage", "Hero", "Character", "Entity"], concept: "Polymorphism" },
      { className: "Character", methodName: "applyStatus()", codeLine: "this._statusEffects.push({ name, duration, value })",
        description: "40% chance to apply Burning. Status effects are stored in _statusEffects, a private array.",
        inheritanceChain: ["Character", "Entity"], concept: "Encapsulation" },
    ],
  },
  rain_of_arrows: {
    actionKey: "rain_of_arrows",
    title: "Archer.specialAbility() — Rain of Arrows",
    summary: "Guaranteed critical hit. Focus stacks reset. Applies Bleeding.",
    steps: [
      { className: "Archer", methodName: "specialAbility()", codeLine: "this._focusStacks = 0; target.applyStatus('Bleeding', 2, 4)",
        description: "Resets focus stacks and guarantees a critical hit. State (_focusStacks) is private to Archer.",
        inheritanceChain: ["Archer", "Hero", "Character", "Entity"], concept: "Encapsulation" },
      { className: "Character", methodName: "tickStatusEffects()", codeLine: "const dmg = this.takeDamage(effect.value)",
        description: "Next turn, tickStatusEffects() will deal bleed damage each tick until duration expires.",
        inheritanceChain: ["Character", "Entity"], concept: "Inheritance" },
    ],
  },
  defend: {
    actionKey: "defend",
    title: "Hero.defend()",
    summary: "Applies a Defending status for +5 defense next turn and restores 10 mana.",
    steps: [
      { className: "Hero", methodName: "defend()", codeLine: "this.applyStatus('Defending', 1, 5); this.restoreMana(10)",
        description: "Defined once in the Hero base class. All heroes (Warrior, Mage, Archer) inherit this without re-implementing.",
        inheritanceChain: ["Hero", "Character", "Entity"], concept: "Inheritance" },
    ],
  },
  goblin_frenzy: {
    actionKey: "goblin_frenzy",
    title: "Goblin.specialAbility() — Frenzy",
    summary: "3 rapid hits in a loop. Total damage shown in the log.",
    steps: [
      { className: "Goblin", methodName: "specialAbility()", codeLine: "for (let i = 0; i < 3; i++) { const dmg = ...; target.takeDamage(dmg) }",
        description: "Goblin overrides specialAbility() from the Enemy abstract class. 3 hits, each at 60% damage.",
        inheritanceChain: ["Goblin", "Enemy", "Character", "Entity"], concept: "Method Override" },
    ],
  },
  troll_regen: {
    actionKey: "troll_regen",
    title: "Troll.decideAction() — super() delegation",
    summary: "Troll checks HP before attacking. If low, heals instead. Then calls super() for normal AI.",
    steps: [
      { className: "Troll", methodName: "decideAction()", codeLine: "if (this.hpPct < 0.5) { return healAction } return super.decideAction(target)",
        description: "Troll conditionally overrides the AI. If HP > 50% it calls super.decideAction() — delegating back to Enemy's default attack logic.",
        inheritanceChain: ["Troll", "Enemy", "Character", "Entity"], concept: "super()" },
    ],
  },
  ground_slam: {
    actionKey: "ground_slam",
    title: "Troll.specialAbility() — Ground Slam",
    summary: "High damage attack defined in Troll, overriding Enemy's abstract specialAbility.",
    steps: [
      { className: "Troll", methodName: "specialAbility()", codeLine: "const dmg = Math.floor(this.calculateBaseDamage() * 1.6) - target.defense",
        description: "Implements the abstract specialAbility() contract from Enemy. Concrete classes must implement it.",
        inheritanceChain: ["Troll", "Enemy", "Character", "Entity"], concept: "Abstraction" },
    ],
  },
  fire_breath: {
    actionKey: "fire_breath",
    title: "Dragon.specialAbility() — Fire Breath",
    summary: "Limited charges (3). When depleted, Dragon falls back to basic attack.",
    steps: [
      { className: "Dragon", methodName: "specialAbility()", codeLine: "if (this._breathCharges <= 0) return super.decideAction(target)",
        description: "_breathCharges is private state unique to Dragon. Encapsulation means no other class can bypass this check.",
        inheritanceChain: ["Dragon", "Enemy", "Character", "Entity"], concept: "Encapsulation" },
      { className: "Character", methodName: "applyStatus()", codeLine: "this._statusEffects.push({ name: 'Burning', duration: 3, value: 6 })",
        description: "Fire Breath applies Burning. applyStatus() is inherited from Character — Dragon doesn't need to re-implement it.",
        inheritanceChain: ["Character", "Entity"], concept: "Inheritance" },
    ],
  },
  soul_drain: {
    actionKey: "soul_drain",
    title: "Lich.specialAbility() — Soul Drain",
    summary: "Deals damage and heals the Lich for 50% of it. Life steal.",
    steps: [
      { className: "Lich", methodName: "specialAbility()", codeLine: "const healed = this.heal(Math.floor(dmg * 0.5))",
        description: "Lich implements specialAbility() from Enemy. Uses Entity.heal() — inherited without override.",
        inheritanceChain: ["Lich", "Enemy", "Character", "Entity"], concept: "Inheritance" },
    ],
  },
  enemy_basic_attack: {
    actionKey: "enemy_basic_attack",
    title: "Enemy.decideAction() — Basic Attack",
    summary: "The default AI defined in the Enemy base class.",
    steps: [
      { className: "Enemy", methodName: "decideAction()", codeLine: "const dmg = Math.max(1, this.calculateBaseDamage() - target.defense)",
        description: "Enemy.decideAction() is the default attack AI. Subclasses like Troll override it, others inherit it directly.",
        inheritanceChain: ["Enemy", "Character", "Entity"], concept: "Inheritance" },
    ],
  },
  status_tick: {
    actionKey: "status_tick",
    title: "Character.tickStatusEffects()",
    summary: "Burning / Bleeding deal damage each turn. Inherited by all combatants.",
    steps: [
      { className: "Character", methodName: "tickStatusEffects()", codeLine: "this._statusEffects = this._statusEffects.filter(s => s.duration > 0)",
        description: "Defined once in Character. Every Hero and Enemy inherits this — no duplication.",
        inheritanceChain: ["Character", "Entity"], concept: "Inheritance" },
    ],
  },
  special_failed: {
    actionKey: "special_failed",
    title: "Hero.spendMana() — Insufficient Mana",
    summary: "Mana check failed. The special ability was not cast.",
    steps: [
      { className: "Hero", methodName: "spendMana()", codeLine: "if (this._mana < amount) return false",
        description: "_mana is a private attribute. External code can't set it directly — only spendMana() and restoreMana() control it.",
        inheritanceChain: ["Hero", "Character"], concept: "Encapsulation" },
    ],
  },
};

export class TraceService {
  static getTrace(actionKey: string): CodeTrace {
    return TRACES[actionKey] ?? TRACES["enemy_basic_attack"];
  }

  static getConcepts() {
    return [
      { id: "abstraction", name: "Abstraction", definition: "Hiding implementation details behind an interface. Entity and Enemy are abstract — you can't instantiate them directly.", codeExample: "abstract class Entity { abstract toSnapshot(): Record<string, unknown> }" },
      { id: "encapsulation", name: "Encapsulation", definition: "Bundling data and methods that operate on it. All attributes use _ prefix (private) and are only accessible via methods.", codeExample: "protected _currentHp: number;\nget currentHp(): number { return this._currentHp; }" },
      { id: "inheritance", name: "Inheritance", definition: "Subclasses inherit all methods from their parent. Warrior gets basicAttack(), defend(), and tickStatusEffects() without re-implementing them.", codeExample: "class Warrior extends Hero extends Character extends Entity" },
      { id: "polymorphism", name: "Polymorphism", definition: "The same method call produces different results depending on the actual object type. calculateBaseDamage() behaves differently for each hero.", codeExample: "hero.calculateBaseDamage() // Warrior adds rage, Mage scales with mana, Archer crits" },
      { id: "method_override", name: "Method Override", definition: "A subclass replaces a parent's implementation. Mage completely replaces basicAttack() so magic bypasses armor.", codeExample: "override basicAttack(target): ActionResult { /* no defense subtraction */ }" },
      { id: "super", name: "super()", definition: "Calls the parent class's version of a method. Warrior uses super() to get the base damage before adding its rage bonus.", codeExample: "const base = super.calculateBaseDamage(); // then add rage bonus" },
      { id: "abstract_methods", name: "Abstract Methods", definition: "Methods declared but not implemented in the parent class. Every hero MUST implement specialAbility() or TypeScript throws a compile error.", codeExample: "abstract specialAbility(target: Character): ActionResult;" },
      { id: "factory", name: "Factory Pattern", definition: "A function that creates objects without exposing constructor logic. createHero('Warrior', 'Arthur') decouples creation from usage.", codeExample: "createHero('Warrior', 'Arthur') // returns new Warrior('Arthur')" },
    ];
  }

  static getClassHierarchy() {
    return {
      id: "Entity", name: "Entity", type: "abstract",
      description: "Root of the hierarchy. Manages name, HP, takeDamage, heal.",
      methods: ["takeDamage()", "heal()", "toSnapshot()"],
      children: [{
        id: "Character", name: "Character", type: "abstract",
        description: "Adds combat stats, mana, and status effects.",
        methods: ["calculateBaseDamage()", "applyStatus()", "tickStatusEffects()", "spendMana()"],
        children: [
          {
            id: "Hero", name: "Hero", type: "abstract",
            description: "Player-controlled. Adds XP, level, basicAttack, defend, and forces specialAbility.",
            methods: ["basicAttack()", "defend()", "gainXp()", "specialAbility() [abstract]"],
            children: [
              { id: "Warrior", name: "Warrior", type: "concrete", description: "Berserker. Damage scales with missing HP via super().", methods: ["calculateBaseDamage() [override+super]", "specialAbility() → Whirlwind"], children: [] },
              { id: "Mage", name: "Mage", type: "concrete", description: "Glass cannon. Overrides basicAttack() to bypass armor.", methods: ["basicAttack() [full override]", "calculateBaseDamage() [mana-scaled]", "specialAbility() → Fireball"], children: [] },
              { id: "Archer", name: "Archer", type: "concrete", description: "Speed + crits. Focus stacks increase crit chance.", methods: ["calculateBaseDamage() [crit system]", "specialAbility() → Rain of Arrows"], children: [] },
            ],
          },
          {
            id: "Enemy", name: "Enemy", type: "abstract",
            description: "AI opponent. Adds wave scaling, xpReward, and AI decision logic.",
            methods: ["decideAction()", "scaleForWave()", "specialAbility() [abstract]"],
            children: [
              { id: "Goblin", name: "Goblin", type: "concrete", description: "Fast, weak. 30% chance to frenzy (3 rapid hits).", methods: ["decideAction() [override]", "specialAbility() → Frenzy"], children: [] },
              { id: "Troll", name: "Troll", type: "concrete", description: "Tank. Heals when below 50% HP, then calls super().", methods: ["decideAction() [override+super]", "specialAbility() → Ground Slam"], children: [] },
              { id: "Dragon", name: "Dragon", type: "concrete", description: "Boss. 3 fire breath charges, then falls back to basic.", methods: ["decideAction() [override]", "specialAbility() → Fire Breath"], children: [] },
              { id: "Lich", name: "Lich", type: "concrete", description: "Life-steal spellcaster.", methods: ["decideAction() [override]", "specialAbility() → Soul Drain"], children: [] },
            ],
          },
        ],
      }],
    };
  }
}
