import { Character, ActionResult } from "./Character";

/**
 * Hero — Abstract class extending Character
 * Demonstrates: Abstract methods, Inheritance chain
 */
export abstract class Hero extends Character {
  protected _heroClass: string;
  protected _xp: number = 0;
  protected _level: number = 1;

  constructor(
    name: string, heroClass: string, maxHp: number, damage: number,
    defense: number, speed: number, maxMana: number
  ) {
    super(name, maxHp, damage, defense, speed, maxMana);
    this._heroClass = heroClass;
  }

  get heroClass(): string { return this._heroClass; }
  get xp(): number { return this._xp; }
  get level(): number { return this._level; }

  gainXp(amount: number): void {
    this._xp += amount;
    this._level = Math.floor(this._xp / 100) + 1;
  }

  basicAttack(target: Character): ActionResult {
    const dmg = Math.max(1, this.calculateBaseDamage() - target.defense);
    target.takeDamage(dmg);
    return {
      actionKey: "basic_attack",
      actorName: this._name,
      targetName: target.name,
      damageDealt: dmg,
      healAmount: 0,
      manaCost: 0,
      logEntry: `${this._name} attacks ${target.name} for ${dmg} damage!`,
      statusApplied: "",
      critical: false,
      success: true,
    };
  }

  defend(): ActionResult {
    this.applyStatus("Defending", 1, 5);
    this.restoreMana(10);
    return {
      actionKey: "defend",
      actorName: this._name,
      targetName: this._name,
      damageDealt: 0,
      healAmount: 0,
      manaCost: 0,
      logEntry: `${this._name} takes a defensive stance and recovers 10 mana.`,
      statusApplied: "Defending",
      critical: false,
      success: true,
    };
  }

  // Abstract — every hero subclass MUST implement this
  abstract specialAbility(target: Character): ActionResult;

  override toSnapshot(): Record<string, unknown> {
    return {
      ...super.toSnapshot(),
      heroClass: this._heroClass,
      xp: this._xp,
      level: this._level,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Warrior — Berserker: damage scales with missing HP
 * Demonstrates: super() chaining, stat-based formula override
 */
export class Warrior extends Hero {
  constructor(name: string) {
    super(name, "Warrior", 150, 20, 8, 6, 50);
  }

  // Override: adds rage bonus based on missing HP
  override calculateBaseDamage(): number {
    const base = super.calculateBaseDamage(); // calls Character.calculateBaseDamage()
    const ragePct = 1 - this.hpPct;
    const rage = Math.floor(ragePct * 15);
    return base + rage;
  }

  override specialAbility(target: Character): ActionResult {
    if (!this.spendMana(20)) {
      return { actionKey: "special_failed", actorName: this._name, targetName: target.name,
        damageDealt: 0, healAmount: 0, manaCost: 0, logEntry: "Not enough mana for Whirlwind!",
        statusApplied: "", critical: false, success: false };
    }
    const dmg = Math.max(1, Math.floor(this.calculateBaseDamage() * 1.5) - target.defense);
    target.takeDamage(dmg);
    return {
      actionKey: "whirlwind_strike",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 20,
      logEntry: `${this._name} unleashes Whirlwind Strike for ${dmg} damage!`,
      statusApplied: "", critical: false, success: true,
    };
  }

  get ragePct(): number { return 1 - this.hpPct; }
}

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Mage — damage bypasses armor, scales with mana
 * Demonstrates: Full method override (basicAttack), mana-scaling formula
 */
export class Mage extends Hero {
  constructor(name: string) {
    super(name, "Mage", 80, 12, 3, 8, 200);
  }

  // Override: magic bypasses armor entirely
  override basicAttack(target: Character): ActionResult {
    const dmg = Math.max(1, this.calculateBaseDamage()); // no defense subtraction
    target.takeDamage(dmg);
    return {
      actionKey: "magic_bolt",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 0,
      logEntry: `${this._name} fires a Magic Bolt for ${dmg} (ignores armor)!`,
      statusApplied: "", critical: false, success: true,
    };
  }

  // Override: spell power scales with mana percentage
  override calculateBaseDamage(): number {
    const spellPower = this._damage + (this._mana / this._maxMana) * 10;
    return Math.floor(spellPower);
  }

  override specialAbility(target: Character): ActionResult {
    if (!this.spendMana(40)) {
      return { actionKey: "special_failed", actorName: this._name, targetName: target.name,
        damageDealt: 0, healAmount: 0, manaCost: 0, logEntry: "Not enough mana for Fireball!",
        statusApplied: "", critical: false, success: false };
    }
    const dmg = Math.max(1, Math.floor(this.calculateBaseDamage() * 2));
    target.takeDamage(dmg);
    let statusApplied = "";
    if (Math.random() < 0.4) {
      target.applyStatus("Burning", 3, 5);
      statusApplied = "Burning";
    }
    return {
      actionKey: "fireball",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 40,
      logEntry: `${this._name} hurls a Fireball for ${dmg}!${statusApplied ? " Target is Burning!" : ""}`,
      statusApplied, critical: false, success: true,
    };
  }

  get spellPower(): number { return this.calculateBaseDamage(); }
}

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Archer — speed + crit system with stacking focus
 * Demonstrates: State accumulation, probabilistic override
 */
export class Archer extends Hero {
  private _focusStacks: number = 0;

  constructor(name: string) {
    super(name, "Archer", 100, 15, 5, 12, 80);
  }

  get focusStacks(): number { return this._focusStacks; }

  // Override: crit chance increases with focus stacks
  override calculateBaseDamage(): number {
    const base = super.calculateBaseDamage();
    const critChance = 0.15 + this._focusStacks * 0.08;
    if (Math.random() < critChance) {
      this._focusStacks = 0;
      return Math.floor(base * 1.8); // crit
    }
    this._focusStacks = Math.min(5, this._focusStacks + 1);
    return base;
  }

  override specialAbility(target: Character): ActionResult {
    if (!this.spendMana(30)) {
      return { actionKey: "special_failed", actorName: this._name, targetName: target.name,
        damageDealt: 0, healAmount: 0, manaCost: 0, logEntry: "Not enough mana for Rain of Arrows!",
        statusApplied: "", critical: false, success: false };
    }
    const dmg = Math.max(1, Math.floor(this._damage * 1.8) - target.defense); // guaranteed crit
    this._focusStacks = 0;
    target.takeDamage(dmg);
    target.applyStatus("Bleeding", 2, 4);
    return {
      actionKey: "rain_of_arrows",
      actorName: this._name, targetName: target.name,
      damageDealt: dmg, healAmount: 0, manaCost: 30,
      logEntry: `${this._name} unleashes Rain of Arrows for ${dmg}! Target is Bleeding!`,
      statusApplied: "Bleeding", critical: true, success: true,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────

export type HeroClass = "Warrior" | "Mage" | "Archer";

export function createHero(heroClass: HeroClass, name: string): Hero {
  switch (heroClass) {
    case "Warrior": return new Warrior(name);
    case "Mage":    return new Mage(name);
    case "Archer":  return new Archer(name);
  }
}
